using System.Text.Json;
using StockManagement.Models;

namespace StockManagement.Services
{
    public interface IApiService
    {
        Task<List<Product>> GetProductsAsync();
        Task<List<ProductCategory>> GetProductCategoriesAsync();
        Task<List<Supplier>> GetSuppliersAsync();
        Task<List<StockTransaction>> GetStockTransactionsAsync();
        Task<List<SalesInvoice>> GetSalesInvoicesAsync();
        Task<List<PurchaseOrder>> GetPurchaseOrdersAsync();
        Task<List<User>> GetUsersAsync();
    }

    public class ApiService : IApiService
    {
        private readonly HttpClient _httpClient;
        private readonly IConfiguration _configuration;
        private readonly JsonSerializerOptions _jsonOptions;

        public ApiService(HttpClient httpClient, IConfiguration configuration)
        {
            _httpClient = httpClient;
            _configuration = configuration;
            _jsonOptions = new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            };
        }

        public async Task<List<Product>> GetProductsAsync()
        {
            try
            {
                var response = await _httpClient.GetAsync("api/products");
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    return JsonSerializer.Deserialize<List<Product>>(json, _jsonOptions) ?? new List<Product>();
                }
                return new List<Product>();
            }
            catch (Exception)
            {
                return new List<Product>();
            }
        }

        public async Task<List<ProductCategory>> GetProductCategoriesAsync()
        {
            try
            {
                var response = await _httpClient.GetAsync("api/productcategory");
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    return JsonSerializer.Deserialize<List<ProductCategory>>(json, _jsonOptions) ?? new List<ProductCategory>();
                }
                return new List<ProductCategory>();
            }
            catch (Exception)
            {
                return new List<ProductCategory>();
            }
        }

        public async Task<List<Supplier>> GetSuppliersAsync()
        {
            try
            {
                var response = await _httpClient.GetAsync("api/supplier");
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    return JsonSerializer.Deserialize<List<Supplier>>(json, _jsonOptions) ?? new List<Supplier>();
                }
                return new List<Supplier>();
            }
            catch (Exception)
            {
                return new List<Supplier>();
            }
        }

        public async Task<List<StockTransaction>> GetStockTransactionsAsync()
        {
            try
            {
                var response = await _httpClient.GetAsync("api/stocktransaction");
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    return JsonSerializer.Deserialize<List<StockTransaction>>(json, _jsonOptions) ?? new List<StockTransaction>();
                }
                return new List<StockTransaction>();
            }
            catch (Exception)
            {
                return new List<StockTransaction>();
            }
        }

        public async Task<List<SalesInvoice>> GetSalesInvoicesAsync()
        {
            try
            {
                var response = await _httpClient.GetAsync("api/salesinvoice");
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    return JsonSerializer.Deserialize<List<SalesInvoice>>(json, _jsonOptions) ?? new List<SalesInvoice>();
                }
                return new List<SalesInvoice>();
            }
            catch (Exception)
            {
                return new List<SalesInvoice>();
            }
        }

        public async Task<List<PurchaseOrder>> GetPurchaseOrdersAsync()
        {
            try
            {
                var response = await _httpClient.GetAsync("api/purchaseorder");
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    return JsonSerializer.Deserialize<List<PurchaseOrder>>(json, _jsonOptions) ?? new List<PurchaseOrder>();
                }
                return new List<PurchaseOrder>();
            }
            catch (Exception)
            {
                return new List<PurchaseOrder>();
            }
        }

        public async Task<List<User>> GetUsersAsync()
        {
            try
            {
                var response = await _httpClient.GetAsync("api/user");
                if (response.IsSuccessStatusCode)
                {
                    var json = await response.Content.ReadAsStringAsync();
                    return JsonSerializer.Deserialize<List<User>>(json, _jsonOptions) ?? new List<User>();
                }
                return new List<User>();
            }
            catch (Exception)
            {
                return new List<User>();
            }
        }
    }
}
