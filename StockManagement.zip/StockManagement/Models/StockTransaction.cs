﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace StockManagement.Models;

public partial class StockTransaction
{
    public int TransactionId { get; set; }

    public int ProductId { get; set; }

    public int? SupplierId { get; set; }

    public int Quantity { get; set; }

    public string? TransactionType { get; set; }

    public DateTime TransactionDate { get; set; }

    public decimal? UnitPrice { get; set; }

    public string? Remarks { get; set; }
    [JsonIgnore]
    public virtual Product Product { get; set; } = null!;
    [JsonIgnore]

    public virtual Supplier? Supplier { get; set; }
}
