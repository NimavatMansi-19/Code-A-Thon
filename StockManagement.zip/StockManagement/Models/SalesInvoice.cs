﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace StockManagement.Models;

public partial class SalesInvoice
{
    public int SalesInvoiceId { get; set; }

    public int UserId { get; set; }

    public string? CustomerName { get; set; }

    public DateTime InvoiceDate { get; set; }

    public decimal? Discount { get; set; }

    public decimal? TaxAmount { get; set; }

    public decimal TotalAmount { get; set; }
    [JsonIgnore]
    public virtual ICollection<SalesInvoiceDetail> SalesInvoiceDetails { get; set; } = new List<SalesInvoiceDetail>();
    [JsonIgnore]
    public virtual User User { get; set; } = null!;
}
