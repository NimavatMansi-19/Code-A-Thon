﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace StockManagement.Models;

public partial class ProductCategory
{
    public int CategoryId { get; set; }

    public string CategoryName { get; set; } = null!;

    public int? ParentCategoryId { get; set; }
    [JsonIgnore]
    public virtual ICollection<ProductCategory> InverseParentCategory { get; set; } = new List<ProductCategory>();
    [JsonIgnore]
    public virtual ProductCategory? ParentCategory { get; set; }
    [JsonIgnore]
    public virtual ICollection<Product> Products { get; set; } = new List<Product>();
}
