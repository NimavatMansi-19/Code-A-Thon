﻿namespace StockManagement.Models
{
    public class UserAdminDto
    {
        public required string UserName { get; set; }
       
    }
}
