﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace StockManagement.Models;

public partial class PurchaseOrder
{
    public int PurchaseOrderId { get; set; }

    public int SupplierId { get; set; }

    public DateTime OrderDate { get; set; }

    public string? Status { get; set; }
    [JsonIgnore]
    public virtual ICollection<PurchaseOrderDetail> PurchaseOrderDetails { get; set; } = new List<PurchaseOrderDetail>();
    [JsonIgnore]
    public virtual Supplier Supplier { get; set; } = null!;
}
