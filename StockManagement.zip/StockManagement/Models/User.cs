﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace StockManagement.Models;

public partial class User
{
    public int UserId { get; set; }

    public required string UserName { get; set; }

    public required string Password { get; set; }

    public string Role { get; set; } = null!;
    [JsonIgnore]
    public virtual ICollection<SalesInvoice> SalesInvoices { get; set; } = new List<SalesInvoice>();
}
public class LoginDTO
{
    public required string UserName { get; set; }
    public required string Password { get; set; }
}
