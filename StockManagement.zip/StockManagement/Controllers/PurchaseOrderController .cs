﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StockManagement.Models;

namespace StockManagement.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PurchaseOrderController : ControllerBase
    {
        private readonly StockManagementSystemContext _context;
        public PurchaseOrderController(StockManagementSystemContext context) { _context = context; }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<PurchaseOrder>>> GetPurchaseOrders() => await _context.PurchaseOrders.ToListAsync();

        [HttpGet("{id}")]
        public async Task<ActionResult<PurchaseOrder>> GetPurchaseOrder(int id)
        {
            var order = await _context.PurchaseOrders.FindAsync(id);
            if (order == null) return NotFound();
            return order;
        }

        [HttpPost]
        public async Task<ActionResult<PurchaseOrder>> CreatePurchaseOrder(PurchaseOrder order)
        {
            _context.PurchaseOrders.Add(order);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetPurchaseOrder), new { id = order.PurchaseOrderId }, order);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdatePurchaseOrder(int id, PurchaseOrder order)
        {
            if (id != order.PurchaseOrderId) return BadRequest();
            _context.Entry(order).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeletePurchaseOrder(int id)
        {
            var order = await _context.PurchaseOrders.FindAsync(id);
            if (order == null) return NotFound();
            _context.PurchaseOrders.Remove(order);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }

    [ApiController]
    [Route("api/[controller]")]
    public class PurchaseOrderDetailController : ControllerBase
    {
        private readonly StockManagementSystemContext _context;
        public PurchaseOrderDetailController(StockManagementSystemContext context) { _context = context; }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<PurchaseOrderDetail>>> GetDetails() => await _context.PurchaseOrderDetails.ToListAsync();

        [HttpGet("{id}")]
        public async Task<ActionResult<PurchaseOrderDetail>> GetDetail(int id)
        {
            var detail = await _context.PurchaseOrderDetails.FindAsync(id);
            if (detail == null) return NotFound();
            return detail;
        }

        [HttpPost]
        public async Task<ActionResult<PurchaseOrderDetail>> CreateDetail(PurchaseOrderDetail detail)
        {
            _context.PurchaseOrderDetails.Add(detail);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetDetail), new { id = detail.PurchaseOrderDetailId}, detail);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateDetail(int id, PurchaseOrderDetail detail)
        {
            if (id != detail.PurchaseOrderDetailId) return BadRequest();
            _context.Entry(detail).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteDetail(int id)
        {
            var detail = await _context.PurchaseOrderDetails.FindAsync(id);
            if (detail == null) return NotFound();
            _context.PurchaseOrderDetails.Remove(detail);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }

}
