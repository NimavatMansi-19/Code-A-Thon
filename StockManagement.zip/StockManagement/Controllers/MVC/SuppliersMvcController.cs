using Microsoft.AspNetCore.Mvc;
using StockManagement.Services;

namespace StockManagement.Controllers.MVC
{
    public class SuppliersMvcController : Controller
    {
        private readonly IApiService _apiService;

        public SuppliersMvcController(IApiService apiService)
        {
            _apiService = apiService;
        }

        public async Task<IActionResult> Index()
        {
            try
            {
                var suppliers = await _apiService.GetSuppliersAsync();
                return View(suppliers);
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                return View(new List<StockManagement.Models.Supplier>());
            }
        }
    }
}
