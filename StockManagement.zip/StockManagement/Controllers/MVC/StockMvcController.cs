using Microsoft.AspNetCore.Mvc;
using StockManagement.Services;

namespace StockManagement.Controllers.MVC
{
    public class StockMvcController : Controller
    {
        private readonly IApiService _apiService;

        public StockMvcController(IApiService apiService)
        {
            _apiService = apiService;
        }

        public async Task<IActionResult> Transactions()
        {
            try
            {
                var transactions = await _apiService.GetStockTransactionsAsync();
                return View(transactions);
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                return View(new List<StockManagement.Models.StockTransaction>());
            }
        }

        public async Task<IActionResult> Sales()
        {
            try
            {
                var sales = await _apiService.GetSalesInvoicesAsync();
                return View(sales);
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                return View(new List<StockManagement.Models.SalesInvoice>());
            }
        }

        public async Task<IActionResult> PurchaseOrders()
        {
            try
            {
                var purchaseOrders = await _apiService.GetPurchaseOrdersAsync();
                return View(purchaseOrders);
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                return View(new List<StockManagement.Models.PurchaseOrder>());
            }
        }
    }
}
