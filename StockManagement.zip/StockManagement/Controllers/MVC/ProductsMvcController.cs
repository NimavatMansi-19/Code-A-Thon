using Microsoft.AspNetCore.Mvc;
using StockManagement.Services;

namespace StockManagement.Controllers.MVC
{
    public class ProductsMvcController : Controller
    {
        private readonly IApiService _apiService;

        public ProductsMvcController(IApiService apiService)
        {
            _apiService = apiService;
        }

        public async Task<IActionResult> Index()
        {
            try
            {
                var products = await _apiService.GetProductsAsync();
                return View(products);
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                return View(new List<StockManagement.Models.Product>());
            }
        }

        public async Task<IActionResult> Categories()
        {
            try
            {
                var categories = await _apiService.GetProductCategoriesAsync();
                return View(categories);
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                return View(new List<StockManagement.Models.ProductCategory>());
            }
        }
    }
}
