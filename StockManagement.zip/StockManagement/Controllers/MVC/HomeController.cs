using Microsoft.AspNetCore.Mvc;
using StockManagement.Services;

namespace StockManagement.Controllers.MVC
{
    public class HomeController : Controller
    {
        private readonly IApiService _apiService;

        public HomeController(IApiService apiService)
        {
            _apiService = apiService;
        }

        public async Task<IActionResult> Index()
        {
            try
            {
                // Get summary data for dashboard
                var products = await _apiService.GetProductsAsync();
                var suppliers = await _apiService.GetSuppliersAsync();
                var transactions = await _apiService.GetStockTransactionsAsync();
                
                ViewBag.ProductCount = products.Count;
                ViewBag.SupplierCount = suppliers.Count;
                ViewBag.TransactionCount = transactions.Count;
                ViewBag.Products = products.Take(5).ToList(); // Show latest 5 products
                
                return View();
            }
            catch (Exception ex)
            {
                ViewBag.Error = ex.Message;
                return View();
            }
        }
    }
}
