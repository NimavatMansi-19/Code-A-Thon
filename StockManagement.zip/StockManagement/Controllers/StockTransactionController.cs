﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StockManagement.Models;

namespace StockManagement.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StockTransactionController : ControllerBase
    {
        private readonly StockManagementSystemContext _context;
        public StockTransactionController(StockManagementSystemContext context) { _context = context; }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<StockTransaction>>> GetTransactions() =>
            await _context.StockTransactions.Include(t => t.Product).Include(t => t.Supplier).ToListAsync();

        [HttpGet("{id}")]
        public async Task<ActionResult<StockTransaction>> GetTransaction(int id)
        {
            var transaction = await _context.StockTransactions.FindAsync(id);
            if (transaction == null) return NotFound();
            return transaction;
        }

        [HttpPost]
        public async Task<ActionResult<StockTransaction>> CreateTransaction(StockTransaction transaction)
        {
            _context.StockTransactions.Add(transaction);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetTransaction), new { id = transaction.TransactionId }, transaction);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateTransaction(int id, StockTransaction transaction)
        {
            if (id != transaction.TransactionId) return BadRequest();
            _context.Entry(transaction).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTransaction(int id)
        {
            var transaction = await _context.StockTransactions.FindAsync(id);
            if (transaction == null) return NotFound();
            _context.StockTransactions.Remove(transaction);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }

}
