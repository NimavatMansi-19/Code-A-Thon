﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using StockManagement.Models;

namespace StockManagement.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class SalesInvoiceController : ControllerBase
    {
        private readonly StockManagementSystemContext _context;
        public SalesInvoiceController(StockManagementSystemContext context) { _context = context; }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<SalesInvoice>>> GetInvoices() => await _context.SalesInvoices.ToListAsync();

        [HttpGet("{id}")]
        public async Task<ActionResult<SalesInvoice>> GetInvoice(int id)
        {
            var invoice = await _context.SalesInvoices.FindAsync(id);
            if (invoice == null) return NotFound();
            return invoice;
        }

        [HttpPost]
        public async Task<ActionResult<SalesInvoice>> CreateInvoice(SalesInvoice invoice)
        {
            _context.SalesInvoices.Add(invoice);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetInvoice), new { id = invoice.SalesInvoiceId }, invoice);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateInvoice(int id, SalesInvoice invoice)
        {
            if (id != invoice.SalesInvoiceId) return BadRequest();
            _context.Entry(invoice).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteInvoice(int id)
        {
            var invoice = await _context.SalesInvoices.FindAsync(id);
            if (invoice == null) return NotFound();
            _context.SalesInvoices.Remove(invoice);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }

    [ApiController]
    [Route("api/[controller]")]
    public class SalesInvoiceDetailController : ControllerBase
    {
        private readonly StockManagementSystemContext _context;
        public SalesInvoiceDetailController(StockManagementSystemContext context) { _context = context; }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<SalesInvoiceDetail>>> GetInvoiceDetails() => await _context.SalesInvoiceDetails.ToListAsync();

        [HttpGet("{id}")]
        public async Task<ActionResult<SalesInvoiceDetail>> GetInvoiceDetail(int id)
        {
            var detail = await _context.SalesInvoiceDetails.FindAsync(id);
            if (detail == null) return NotFound();
            return detail;
        }

        [HttpPost]
        public async Task<ActionResult<SalesInvoiceDetail>> CreateInvoiceDetail(SalesInvoiceDetail detail)
        {
            _context.SalesInvoiceDetails.Add(detail);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetInvoiceDetail), new { id = detail.SalesInvoiceDetailId }, detail);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateInvoiceDetail(int id, SalesInvoiceDetail detail)
        {
            if (id != detail.SalesInvoiceDetailId) return BadRequest();
            _context.Entry(detail).State = EntityState.Modified;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteInvoiceDetail(int id)
        {
            var detail = await _context.SalesInvoiceDetails.FindAsync(id);
            if (detail == null) return NotFound();
            _context.SalesInvoiceDetails.Remove(detail);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }

}
