export interface User {
  id: string
  email: string
  name: string
  role: "owner" | "manager" | "staff"
  createdAt: Date
  updatedAt: Date
}

export interface Category {
  id: string
  name: string
  description?: string
  parentId?: string
  createdAt: Date
  updatedAt: Date
}

export interface Supplier {
  id: string
  name: string
  email?: string
  phone?: string
  address?: string
  contactPerson?: string
  createdAt: Date
  updatedAt: Date
}

export interface Product {
  id: string
  name: string
  description?: string
  sku: string
  barcode?: string
  categoryId: string
  supplierId: string
  unit: string
  costPrice: number
  sellingPrice: number
  stockLevel: number
  minStockLevel: number
  maxStockLevel?: number
  expiryDate?: Date
  batchNumber?: string
  createdAt: Date
  updatedAt: Date
}

export interface StockMovement {
  id: string
  productId: string
  type: "in" | "out" | "adjustment"
  quantity: number
  reason: string
  reference?: string
  userId: string
  createdAt: Date
}

export interface PurchaseOrder {
  id: string
  supplierId: string
  orderNumber: string
  status: "pending" | "ordered" | "received" | "cancelled"
  orderDate: Date
  expectedDate?: Date
  receivedDate?: Date
  totalAmount: number
  notes?: string
  createdAt: Date
  updatedAt: Date
}

export interface PurchaseOrderItem {
  id: string
  purchaseOrderId: string
  productId: string
  quantity: number
  unitPrice: number
  receivedQuantity?: number
}

export interface Sale {
  id: string
  saleNumber: string
  customerId?: string
  userId: string
  totalAmount: number
  discountAmount: number
  taxAmount: number
  finalAmount: number
  paymentMethod: "cash" | "card" | "transfer"
  status: "completed" | "refunded" | "cancelled"
  saleDate: Date
  createdAt: Date
}

export interface SaleItem {
  id: string
  saleId: string
  productId: string
  quantity: number
  unitPrice: number
  discountAmount: number
  totalAmount: number
}

export interface DashboardMetrics {
  totalStockValue: number
  lowStockItems: number
  todaysSales: number
  totalProducts: number
  totalSuppliers: number
  pendingOrders: number
}
