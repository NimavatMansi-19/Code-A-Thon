import type { Category, Supplier, Product, User, DashboardMetrics } from "./types"

export const mockUsers: User[] = [
  {
    id: "1",
    email: "owner@store.com",
    name: "John Smith",
    role: "owner",
    createdAt: new Date("2024-01-01"),
    updatedAt: new Date("2024-01-01"),
  },
  {
    id: "2",
    email: "manager@store.com",
    name: "Sarah Johnson",
    role: "manager",
    createdAt: new Date("2024-01-15"),
    updatedAt: new Date("2024-01-15"),
  },
]

export const mockCategories: Category[] = [
  {
    id: "1",
    name: "Electronics",
    description: "Electronic devices and accessories",
    createdAt: new Date("2024-01-01"),
    updatedAt: new Date("2024-01-01"),
  },
  {
    id: "2",
    name: "Clothing",
    description: "Apparel and fashion items",
    createdAt: new Date("2024-01-01"),
    updatedAt: new Date("2024-01-01"),
  },
  {
    id: "3",
    name: "Food & Beverages",
    description: "Food items and drinks",
    createdAt: new Date("2024-01-01"),
    updatedAt: new Date("2024-01-01"),
  },
]

export const mockSuppliers: Supplier[] = [
  {
    id: "1",
    name: "Tech Distributors Inc.",
    email: "orders@techdist.com",
    phone: "+1-555-0123",
    address: "123 Business Ave, Tech City, TC 12345",
    contactPerson: "Mike Wilson",
    createdAt: new Date("2024-01-01"),
    updatedAt: new Date("2024-01-01"),
  },
  {
    id: "2",
    name: "Fashion Wholesale Co.",
    email: "sales@fashionwholesale.com",
    phone: "+1-555-0456",
    address: "456 Fashion St, Style City, SC 67890",
    contactPerson: "Lisa Chen",
    createdAt: new Date("2024-01-01"),
    updatedAt: new Date("2024-01-01"),
  },
]

export const mockProducts: Product[] = [
  {
    id: "1",
    name: "Wireless Headphones",
    description: "Bluetooth wireless headphones with noise cancellation",
    sku: "WH-001",
    barcode: "1234567890123",
    categoryId: "1",
    supplierId: "1",
    unit: "piece",
    costPrice: 45.0,
    sellingPrice: 79.99,
    stockLevel: 25,
    minStockLevel: 10,
    maxStockLevel: 100,
    createdAt: new Date("2024-01-01"),
    updatedAt: new Date("2024-01-01"),
  },
  {
    id: "2",
    name: "Cotton T-Shirt",
    description: "100% cotton casual t-shirt",
    sku: "TS-001",
    barcode: "2345678901234",
    categoryId: "2",
    supplierId: "2",
    unit: "piece",
    costPrice: 8.0,
    sellingPrice: 19.99,
    stockLevel: 5,
    minStockLevel: 15,
    maxStockLevel: 200,
    createdAt: new Date("2024-01-01"),
    updatedAt: new Date("2024-01-01"),
  },
  {
    id: "3",
    name: "Energy Drink",
    description: "Caffeinated energy drink 250ml",
    sku: "ED-001",
    barcode: "3456789012345",
    categoryId: "3",
    supplierId: "1",
    unit: "can",
    costPrice: 1.2,
    sellingPrice: 2.99,
    stockLevel: 150,
    minStockLevel: 50,
    maxStockLevel: 500,
    expiryDate: new Date("2024-12-31"),
    batchNumber: "B2024001",
    createdAt: new Date("2024-01-01"),
    updatedAt: new Date("2024-01-01"),
  },
]

export const mockDashboardMetrics: DashboardMetrics = {
  totalStockValue: 4247.75,
  lowStockItems: 1,
  todaysSales: 156.97,
  totalProducts: 3,
  totalSuppliers: 2,
  pendingOrders: 2,
}
