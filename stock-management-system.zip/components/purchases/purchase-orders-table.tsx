"use client"

import { useState } from "react"
import type { PurchaseOrder, PurchaseOrderItem } from "@/lib/types"
import { mockSuppliers } from "@/lib/mock-data"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Search, Plus, Eye, Edit, Package } from "lucide-react"
import { PurchaseOrderDialog } from "./purchase-order-dialog"

// Mock purchase orders data
const mockPurchaseOrders: (PurchaseOrder & { items: PurchaseOrderItem[] })[] = [
  {
    id: "1",
    supplierId: "1",
    orderNumber: "PO-001",
    status: "pending",
    orderDate: new Date("2024-01-15"),
    expectedDate: new Date("2024-01-25"),
    totalAmount: 2250.0,
    notes: "Urgent order for electronics",
    createdAt: new Date("2024-01-15"),
    updatedAt: new Date("2024-01-15"),
    items: [
      {
        id: "1",
        purchaseOrderId: "1",
        productId: "1",
        quantity: 50,
        unitPrice: 45.0,
      },
    ],
  },
  {
    id: "2",
    supplierId: "2",
    orderNumber: "PO-002",
    status: "received",
    orderDate: new Date("2024-01-10"),
    expectedDate: new Date("2024-01-20"),
    receivedDate: new Date("2024-01-18"),
    totalAmount: 800.0,
    createdAt: new Date("2024-01-10"),
    updatedAt: new Date("2024-01-18"),
    items: [
      {
        id: "2",
        purchaseOrderId: "2",
        productId: "2",
        quantity: 100,
        unitPrice: 8.0,
      },
    ],
  },
]

export function PurchaseOrdersTable() {
  const [purchaseOrders, setPurchaseOrders] = useState(mockPurchaseOrders)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedOrder, setSelectedOrder] = useState<(PurchaseOrder & { items: PurchaseOrderItem[] }) | null>(null)
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  const getSupplierName = (supplierId: string) => {
    return mockSuppliers.find((s) => s.id === supplierId)?.name || "Unknown"
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="secondary">Pending</Badge>
      case "ordered":
        return <Badge className="bg-blue-100 text-blue-800 border-blue-200">Ordered</Badge>
      case "received":
        return <Badge className="bg-green-100 text-green-800 border-green-200">Received</Badge>
      case "cancelled":
        return <Badge variant="destructive">Cancelled</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const filteredOrders = purchaseOrders.filter(
    (order) =>
      order.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      getSupplierName(order.supplierId).toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const handleAdd = () => {
    setSelectedOrder(null)
    setIsDialogOpen(true)
  }

  const handleEdit = (order: PurchaseOrder & { items: PurchaseOrderItem[] }) => {
    setSelectedOrder(order)
    setIsDialogOpen(true)
  }

  const handleReceiveGoods = (orderId: string) => {
    setPurchaseOrders(
      purchaseOrders.map((order) =>
        order.id === orderId
          ? {
              ...order,
              status: "received" as const,
              receivedDate: new Date(),
              updatedAt: new Date(),
            }
          : order,
      ),
    )
  }

  const handleSave = (orderData: Partial<PurchaseOrder & { items: PurchaseOrderItem[] }>) => {
    if (selectedOrder) {
      setPurchaseOrders(
        purchaseOrders.map((order) =>
          order.id === selectedOrder.id ? { ...selectedOrder, ...orderData, updatedAt: new Date() } : order,
        ),
      )
    } else {
      const newOrder = {
        id: Date.now().toString(),
        orderNumber: `PO-${String(purchaseOrders.length + 1).padStart(3, "0")}`,
        createdAt: new Date(),
        updatedAt: new Date(),
        ...(orderData as PurchaseOrder & { items: PurchaseOrderItem[] }),
      }
      setPurchaseOrders([...purchaseOrders, newOrder])
    }
    setIsDialogOpen(false)
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Purchase Orders</CardTitle>
            <Button onClick={handleAdd}>
              <Plus className="mr-2 h-4 w-4" />
              Create Purchase Order
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-2 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Search purchase orders..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Order Number</TableHead>
                  <TableHead>Supplier</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Order Date</TableHead>
                  <TableHead>Expected Date</TableHead>
                  <TableHead>Total Amount</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredOrders.map((order) => (
                  <TableRow key={order.id}>
                    <TableCell className="font-medium">{order.orderNumber}</TableCell>
                    <TableCell>{getSupplierName(order.supplierId)}</TableCell>
                    <TableCell>{getStatusBadge(order.status)}</TableCell>
                    <TableCell>{order.orderDate.toLocaleDateString()}</TableCell>
                    <TableCell>{order.expectedDate?.toLocaleDateString() || "—"}</TableCell>
                    <TableCell>${order.totalAmount.toFixed(2)}</TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <Button variant="ghost" size="sm" onClick={() => handleEdit(order)}>
                          <Eye className="h-4 w-4" />
                        </Button>
                        {order.status === "ordered" && (
                          <Button variant="ghost" size="sm" onClick={() => handleReceiveGoods(order.id)}>
                            <Package className="h-4 w-4" />
                          </Button>
                        )}
                        {order.status === "pending" && (
                          <Button variant="ghost" size="sm" onClick={() => handleEdit(order)}>
                            <Edit className="h-4 w-4" />
                          </Button>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <PurchaseOrderDialog
        order={selectedOrder}
        open={isDialogOpen}
        onOpenChange={setIsDialogOpen}
        onSave={handleSave}
      />
    </div>
  )
}
