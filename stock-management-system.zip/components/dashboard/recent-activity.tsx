"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Package, ShoppingCart, DollarSign, Users } from "lucide-react"

const recentActivities = [
  {
    id: "1",
    type: "sale",
    description: "Sale INV-003 completed",
    amount: "$9.78",
    time: "2 hours ago",
    icon: DollarSign,
    color: "text-green-600",
  },
  {
    id: "2",
    type: "stock",
    description: "Stock adjustment for Wireless Headphones",
    amount: "+25 units",
    time: "4 hours ago",
    icon: Package,
    color: "text-blue-600",
  },
  {
    id: "3",
    type: "purchase",
    description: "Purchase Order PO-002 received",
    amount: "$800.00",
    time: "1 day ago",
    icon: ShoppingCart,
    color: "text-purple-600",
  },
  {
    id: "4",
    type: "supplier",
    description: "New supplier Fashion Wholesale Co. added",
    amount: "",
    time: "2 days ago",
    icon: Users,
    color: "text-orange-600",
  },
]

export function RecentActivity() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Recent Activity</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {recentActivities.map((activity) => (
            <div key={activity.id} className="flex items-center space-x-4">
              <div className={`p-2 rounded-full bg-muted ${activity.color}`}>
                <activity.icon className="h-4 w-4" />
              </div>
              <div className="flex-1 space-y-1">
                <p className="text-sm font-medium">{activity.description}</p>
                <p className="text-xs text-muted-foreground">{activity.time}</p>
              </div>
              {activity.amount && (
                <Badge variant="outline" className="font-mono">
                  {activity.amount}
                </Badge>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
