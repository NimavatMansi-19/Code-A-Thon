"use client"

import { useState } from "react"
import type { StockMovement } from "@/lib/types"
import { mockProducts, mockUsers } from "@/lib/mock-data"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Plus, Minus, RotateCcw } from "lucide-react"

// Mock stock movements data
const mockStockMovements: StockMovement[] = [
  {
    id: "1",
    productId: "1",
    type: "in",
    quantity: 50,
    reason: "Initial stock purchase",
    reference: "PO-001",
    userId: "1",
    createdAt: new Date("2024-01-15"),
  },
  {
    id: "2",
    productId: "2",
    type: "out",
    quantity: 10,
    reason: "Sales",
    userId: "2",
    createdAt: new Date("2024-01-16"),
  },
  {
    id: "3",
    productId: "1",
    type: "adjustment",
    quantity: 25,
    reason: "Stock count correction",
    userId: "1",
    createdAt: new Date("2024-01-17"),
  },
  {
    id: "4",
    productId: "3",
    type: "in",
    quantity: 200,
    reason: "Supplier delivery",
    reference: "PO-002",
    userId: "1",
    createdAt: new Date("2024-01-18"),
  },
]

export function StockMovements() {
  const [movements] = useState<StockMovement[]>(mockStockMovements)
  const [searchTerm, setSearchTerm] = useState("")
  const [typeFilter, setTypeFilter] = useState<string>("all")

  const getProductName = (productId: string) => {
    return mockProducts.find((p) => p.id === productId)?.name || "Unknown Product"
  }

  const getUserName = (userId: string) => {
    return mockUsers.find((u) => u.id === userId)?.name || "Unknown User"
  }

  const getMovementIcon = (type: string) => {
    switch (type) {
      case "in":
        return <Plus className="h-4 w-4 text-primary" />
      case "out":
        return <Minus className="h-4 w-4 text-destructive" />
      case "adjustment":
        return <RotateCcw className="h-4 w-4 text-secondary" />
      default:
        return null
    }
  }

  const getMovementBadge = (type: string) => {
    switch (type) {
      case "in":
        return <Badge className="bg-primary/10 text-primary border-primary/20">Stock In</Badge>
      case "out":
        return <Badge className="bg-destructive/10 text-destructive border-destructive/20">Stock Out</Badge>
      case "adjustment":
        return <Badge className="bg-secondary/10 text-secondary border-secondary/20">Adjustment</Badge>
      default:
        return <Badge variant="outline">{type}</Badge>
    }
  }

  const filteredMovements = movements.filter((movement) => {
    const matchesSearch =
      getProductName(movement.productId).toLowerCase().includes(searchTerm.toLowerCase()) ||
      movement.reason.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesType = typeFilter === "all" || movement.type === typeFilter
    return matchesSearch && matchesType
  })

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Stock Movement History</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-4 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Search by product or reason..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-48">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="in">Stock In</SelectItem>
                <SelectItem value="out">Stock Out</SelectItem>
                <SelectItem value="adjustment">Adjustments</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Product</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Quantity</TableHead>
                  <TableHead>Reason</TableHead>
                  <TableHead>Reference</TableHead>
                  <TableHead>User</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredMovements.map((movement) => (
                  <TableRow key={movement.id}>
                    <TableCell>{movement.createdAt.toLocaleDateString()}</TableCell>
                    <TableCell className="font-medium">{getProductName(movement.productId)}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {getMovementIcon(movement.type)}
                        {getMovementBadge(movement.type)}
                      </div>
                    </TableCell>
                    <TableCell>
                      <span className={movement.type === "out" ? "text-destructive" : "text-primary"}>
                        {movement.type === "out" ? "-" : "+"}
                        {movement.quantity}
                      </span>
                    </TableCell>
                    <TableCell>{movement.reason}</TableCell>
                    <TableCell>{movement.reference || "—"}</TableCell>
                    <TableCell>{getUserName(movement.userId)}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
