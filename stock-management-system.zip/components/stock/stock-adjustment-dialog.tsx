"use client"

import type React from "react"

import { useState, useEffect } from "react"
import type { Product } from "@/lib/types"
import { useAuth } from "@/lib/auth-context"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Plus, Minus, RotateCcw } from "lucide-react"

interface StockAdjustmentDialogProps {
  product: Product | null
  open: boolean
  onOpenChange: (open: boolean) => void
}

export function StockAdjustmentDialog({ product, open, onOpenChange }: StockAdjustmentDialogProps) {
  const { user } = useAuth()
  const [adjustmentType, setAdjustmentType] = useState<"in" | "out" | "adjustment">("in")
  const [quantity, setQuantity] = useState(0)
  const [reason, setReason] = useState("")
  const [reference, setReference] = useState("")

  useEffect(() => {
    if (open) {
      setQuantity(0)
      setReason("")
      setReference("")
      setAdjustmentType("in")
    }
  }, [open])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!product || !user) return

    // In a real app, this would make an API call to record the stock movement
    const stockMovement = {
      id: Date.now().toString(),
      productId: product.id,
      type: adjustmentType,
      quantity,
      reason,
      reference,
      userId: user.id,
      createdAt: new Date(),
    }

    console.log("[v0] Stock movement recorded:", stockMovement)

    // Update the product stock level (in a real app, this would be handled by the backend)
    let newStockLevel = product.stockLevel
    if (adjustmentType === "in") {
      newStockLevel += quantity
    } else if (adjustmentType === "out") {
      newStockLevel -= quantity
    } else {
      newStockLevel = quantity // For adjustments, quantity is the new total
    }

    console.log("[v0] Updated stock level:", newStockLevel)

    onOpenChange(false)
  }

  const getAdjustmentIcon = () => {
    switch (adjustmentType) {
      case "in":
        return <Plus className="h-4 w-4" />
      case "out":
        return <Minus className="h-4 w-4" />
      case "adjustment":
        return <RotateCcw className="h-4 w-4" />
    }
  }

  const getNewStockLevel = () => {
    if (!product) return 0
    if (adjustmentType === "in") {
      return product.stockLevel + quantity
    }
    if (adjustmentType === "out") {
      return Math.max(0, product.stockLevel - quantity)
    }
    return quantity // For adjustments, quantity is the new total
  }

  if (!product) return null

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {getAdjustmentIcon()}
            Stock Adjustment
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="p-4 bg-muted rounded-lg">
            <div className="font-medium">{product.name}</div>
            <div className="text-sm text-muted-foreground">
              Current Stock: {product.stockLevel} {product.unit}
            </div>
            <div className="text-sm text-muted-foreground">SKU: {product.sku}</div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="type">Adjustment Type</Label>
              <Select value={adjustmentType} onValueChange={(value: any) => setAdjustmentType(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="in">Stock In (+)</SelectItem>
                  <SelectItem value="out">Stock Out (-)</SelectItem>
                  <SelectItem value="adjustment">Stock Adjustment (Set Total)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="quantity">{adjustmentType === "adjustment" ? "New Stock Level" : "Quantity"}</Label>
              <Input
                id="quantity"
                type="number"
                min="0"
                value={quantity}
                onChange={(e) => setQuantity(Number.parseInt(e.target.value) || 0)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="reason">Reason *</Label>
              <Textarea
                id="reason"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="Enter reason for stock adjustment..."
                required
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="reference">Reference (Optional)</Label>
              <Input
                id="reference"
                value={reference}
                onChange={(e) => setReference(e.target.value)}
                placeholder="PO number, invoice, etc."
              />
            </div>

            {quantity > 0 && (
              <Alert>
                <AlertDescription>
                  New stock level will be:{" "}
                  <strong>
                    {getNewStockLevel()} {product.unit}
                  </strong>
                </AlertDescription>
              </Alert>
            )}

            <div className="flex justify-end space-x-2 pt-4">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button type="submit">Record Adjustment</Button>
            </div>
          </form>
        </div>
      </DialogContent>
    </Dialog>
  )
}
