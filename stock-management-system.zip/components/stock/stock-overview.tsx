"use client"

import { useState } from "react"
import { mockProducts, mockCategories } from "@/lib/mock-data"
import type { Product } from "@/lib/types"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { AlertTriangle, TrendingDown, Package, DollarSign } from "lucide-react"
import { StockAdjustmentDialog } from "./stock-adjustment-dialog"

export function StockOverview() {
  const [products] = useState<Product[]>(mockProducts)
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [isAdjustmentDialogOpen, setIsAdjustmentDialogOpen] = useState(false)

  const getCategoryName = (categoryId: string) => {
    return mockCategories.find((cat) => cat.id === categoryId)?.name || "Unknown"
  }

  const getStockStatus = (product: Product) => {
    if (product.stockLevel <= product.minStockLevel) {
      return { status: "critical", color: "destructive", label: "Critical" }
    }
    if (product.stockLevel <= product.minStockLevel * 1.5) {
      return { status: "low", color: "secondary", label: "Low" }
    }
    return { status: "good", color: "default", label: "Good" }
  }

  const lowStockProducts = products.filter((p) => p.stockLevel <= p.minStockLevel)
  const criticalStockProducts = products.filter((p) => p.stockLevel <= p.minStockLevel * 0.5)
  const totalStockValue = products.reduce((sum, p) => sum + p.stockLevel * p.costPrice, 0)
  const totalProducts = products.length

  const handleAdjustStock = (product: Product) => {
    setSelectedProduct(product)
    setIsAdjustmentDialogOpen(true)
  }

  return (
    <div className="space-y-6">
      {/* Stock Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Products</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalProducts}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Stock Value</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${totalStockValue.toFixed(2)}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Low Stock Items</CardTitle>
            <TrendingDown className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-secondary">{lowStockProducts.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Critical Stock</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive">{criticalStockProducts.length}</div>
          </CardContent>
        </Card>
      </div>

      {/* Low Stock Alerts */}
      {lowStockProducts.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-destructive" />
              Low Stock Alerts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {lowStockProducts.map((product) => (
                <div
                  key={product.id}
                  className="flex items-center justify-between p-3 border rounded-lg bg-destructive/5"
                >
                  <div>
                    <div className="font-medium">{product.name}</div>
                    <div className="text-sm text-muted-foreground">
                      Current: {product.stockLevel} {product.unit} | Min: {product.minStockLevel} {product.unit}
                    </div>
                  </div>
                  <Button size="sm" onClick={() => handleAdjustStock(product)}>
                    Adjust Stock
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* All Products Stock Status */}
      <Card>
        <CardHeader>
          <CardTitle>Stock Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Product</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Current Stock</TableHead>
                  <TableHead>Min Level</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Value</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {products.map((product) => {
                  const stockStatus = getStockStatus(product)
                  const stockValue = product.stockLevel * product.costPrice
                  return (
                    <TableRow key={product.id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{product.name}</div>
                          <div className="text-sm text-muted-foreground">{product.sku}</div>
                        </div>
                      </TableCell>
                      <TableCell>{getCategoryName(product.categoryId)}</TableCell>
                      <TableCell>
                        {product.stockLevel} {product.unit}
                      </TableCell>
                      <TableCell>
                        {product.minStockLevel} {product.unit}
                      </TableCell>
                      <TableCell>
                        <Badge variant={stockStatus.color as any}>{stockStatus.label}</Badge>
                      </TableCell>
                      <TableCell>${stockValue.toFixed(2)}</TableCell>
                      <TableCell>
                        <Button variant="outline" size="sm" onClick={() => handleAdjustStock(product)}>
                          Adjust
                        </Button>
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <StockAdjustmentDialog
        product={selectedProduct}
        open={isAdjustmentDialogOpen}
        onOpenChange={setIsAdjustmentDialogOpen}
      />
    </div>
  )
}
