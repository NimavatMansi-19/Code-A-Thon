"use client"

import { useState } from "react"
import type { Sale, SaleItem } from "@/lib/types"
import { mockUsers } from "@/lib/mock-data"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Search, Plus, Eye, FileText, CreditCard, Banknote, Smartphone } from "lucide-react"
import { SaleDialog } from "./sale-dialog"

// Mock sales data
const mockSales: (Sale & { items: SaleItem[] })[] = [
  {
    id: "1",
    saleNumber: "INV-001",
    customerId: undefined,
    userId: "1",
    totalAmount: 79.99,
    discountAmount: 0,
    taxAmount: 7.2,
    finalAmount: 87.19,
    paymentMethod: "card",
    status: "completed",
    saleDate: new Date("2024-01-18"),
    createdAt: new Date("2024-01-18"),
    items: [
      {
        id: "1",
        saleId: "1",
        productId: "1",
        quantity: 1,
        unitPrice: 79.99,
        discountAmount: 0,
        totalAmount: 79.99,
      },
    ],
  },
  {
    id: "2",
    saleNumber: "INV-002",
    customerId: undefined,
    userId: "2",
    totalAmount: 39.98,
    discountAmount: 4.0,
    taxAmount: 3.24,
    finalAmount: 39.22,
    paymentMethod: "cash",
    status: "completed",
    saleDate: new Date("2024-01-19"),
    createdAt: new Date("2024-01-19"),
    items: [
      {
        id: "2",
        saleId: "2",
        productId: "2",
        quantity: 2,
        unitPrice: 19.99,
        discountAmount: 4.0,
        totalAmount: 35.98,
      },
    ],
  },
  {
    id: "3",
    saleNumber: "INV-003",
    customerId: undefined,
    userId: "1",
    totalAmount: 8.97,
    discountAmount: 0,
    taxAmount: 0.81,
    finalAmount: 9.78,
    paymentMethod: "transfer",
    status: "completed",
    saleDate: new Date("2024-01-20"),
    createdAt: new Date("2024-01-20"),
    items: [
      {
        id: "3",
        saleId: "3",
        productId: "3",
        quantity: 3,
        unitPrice: 2.99,
        discountAmount: 0,
        totalAmount: 8.97,
      },
    ],
  },
]

export function SalesTable() {
  const [sales, setSales] = useState(mockSales)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedSale, setSelectedSale] = useState<(Sale & { items: SaleItem[] }) | null>(null)
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  const getUserName = (userId: string) => {
    return mockUsers.find((u) => u.id === userId)?.name || "Unknown"
  }

  const getPaymentIcon = (method: string) => {
    switch (method) {
      case "cash":
        return <Banknote className="h-4 w-4" />
      case "card":
        return <CreditCard className="h-4 w-4" />
      case "transfer":
        return <Smartphone className="h-4 w-4" />
      default:
        return null
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge className="bg-green-100 text-green-800 border-green-200">Completed</Badge>
      case "refunded":
        return <Badge variant="destructive">Refunded</Badge>
      case "cancelled":
        return <Badge variant="secondary">Cancelled</Badge>
      default:
        return <Badge variant="outline">{status}</Badge>
    }
  }

  const filteredSales = sales.filter(
    (sale) =>
      sale.saleNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      getUserName(sale.userId).toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const handleAdd = () => {
    setSelectedSale(null)
    setIsDialogOpen(true)
  }

  const handleView = (sale: Sale & { items: SaleItem[] }) => {
    setSelectedSale(sale)
    setIsDialogOpen(true)
  }

  const handleSave = (saleData: Partial<Sale & { items: SaleItem[] }>) => {
    if (selectedSale) {
      setSales(sales.map((sale) => (sale.id === selectedSale.id ? { ...selectedSale, ...saleData } : sale)))
    } else {
      const newSale = {
        id: Date.now().toString(),
        saleNumber: `INV-${String(sales.length + 1).padStart(3, "0")}`,
        createdAt: new Date(),
        ...(saleData as Sale & { items: SaleItem[] }),
      }
      setSales([...sales, newSale])
    }
    setIsDialogOpen(false)
  }

  const totalSales = sales.reduce((sum, sale) => sum + sale.finalAmount, 0)
  const todaysSales = sales
    .filter((sale) => sale.saleDate.toDateString() === new Date().toDateString())
    .reduce((sum, sale) => sum + sale.finalAmount, 0)

  return (
    <div className="space-y-6">
      {/* Sales Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Sales</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{sales.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <CreditCard className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${totalSales.toFixed(2)}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Today's Sales</CardTitle>
            <Banknote className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${todaysSales.toFixed(2)}</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Sales & Invoices</CardTitle>
            <Button onClick={handleAdd}>
              <Plus className="mr-2 h-4 w-4" />
              Create Sale
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-2 mb-6">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
              <Input
                placeholder="Search sales..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>

          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Invoice #</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Staff</TableHead>
                  <TableHead>Items</TableHead>
                  <TableHead>Subtotal</TableHead>
                  <TableHead>Discount</TableHead>
                  <TableHead>Tax</TableHead>
                  <TableHead>Total</TableHead>
                  <TableHead>Payment</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredSales.map((sale) => (
                  <TableRow key={sale.id}>
                    <TableCell className="font-medium">{sale.saleNumber}</TableCell>
                    <TableCell>{sale.saleDate.toLocaleDateString()}</TableCell>
                    <TableCell>{getUserName(sale.userId)}</TableCell>
                    <TableCell>{sale.items.length}</TableCell>
                    <TableCell>${sale.totalAmount.toFixed(2)}</TableCell>
                    <TableCell>${sale.discountAmount.toFixed(2)}</TableCell>
                    <TableCell>${sale.taxAmount.toFixed(2)}</TableCell>
                    <TableCell className="font-medium">${sale.finalAmount.toFixed(2)}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {getPaymentIcon(sale.paymentMethod)}
                        <span className="capitalize">{sale.paymentMethod}</span>
                      </div>
                    </TableCell>
                    <TableCell>{getStatusBadge(sale.status)}</TableCell>
                    <TableCell>
                      <Button variant="ghost" size="sm" onClick={() => handleView(sale)}>
                        <Eye className="h-4 w-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <SaleDialog sale={selectedSale} open={isDialogOpen} onOpenChange={setIsDialogOpen} onSave={handleSave} />
    </div>
  )
}
