import { ProtectedRoute } from "@/components/auth/protected-route"
import { MainLayout } from "@/components/layout/main-layout"
import { CategoryTable } from "@/components/categories/category-table"

export default function CategoriesPage() {
  return (
    <ProtectedRoute>
      <MainLayout>
        <div className="p-6">
          <CategoryTable />
        </div>
      </MainLayout>
    </ProtectedRoute>
  )
}
