import { ProtectedRoute } from "@/components/auth/protected-route"
import { MainLayout } from "@/components/layout/main-layout"
import { SalesTable } from "@/components/sales/sales-table"

export default function BillsPage() {
  return (
    <ProtectedRoute>
      <MainLayout>
        <div className="p-6">
          <div className="mb-6">
            <h1 className="text-3xl font-bold text-primary">Bills & Invoicing</h1>
            <p className="text-muted-foreground">Manage sales, generate invoices, and track payments</p>
          </div>
          <SalesTable />
        </div>
      </MainLayout>
    </ProtectedRoute>
  )
}
