import { ProtectedRoute } from "@/components/auth/protected-route"
import { MainLayout } from "@/components/layout/main-layout"
import { ReportsDashboard } from "@/components/reports/reports-dashboard"

export default function ReportsPage() {
  return (
    <ProtectedRoute>
      <MainLayout>
        <div className="p-6">
          <div className="mb-6">
            <h1 className="text-3xl font-bold text-primary">Reports & Analytics</h1>
            <p className="text-muted-foreground">Generate comprehensive reports and analyze your business data</p>
          </div>
          <ReportsDashboard />
        </div>
      </MainLayout>
    </ProtectedRoute>
  )
}
