import { ProtectedRoute } from "@/components/auth/protected-route"
import { MainLayout } from "@/components/layout/main-layout"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { SupplierTable } from "@/components/suppliers/supplier-table"
import { PurchaseOrdersTable } from "@/components/purchases/purchase-orders-table"

export default function SuppliersPage() {
  return (
    <ProtectedRoute>
      <MainLayout>
        <div className="p-6">
          <div className="mb-6">
            <h1 className="text-3xl font-bold text-primary">Supplier & Purchase Management</h1>
            <p className="text-muted-foreground">Manage suppliers and track purchase orders</p>
          </div>

          <Tabs defaultValue="suppliers" className="space-y-6">
            <TabsList>
              <TabsTrigger value="suppliers">Suppliers</TabsTrigger>
              <TabsTrigger value="purchases">Purchase Orders</TabsTrigger>
            </TabsList>

            <TabsContent value="suppliers">
              <SupplierTable />
            </TabsContent>

            <TabsContent value="purchases">
              <PurchaseOrdersTable />
            </TabsContent>
          </Tabs>
        </div>
      </MainLayout>
    </ProtectedRoute>
  )
}
