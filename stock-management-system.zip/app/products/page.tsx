import { ProtectedRoute } from "@/components/auth/protected-route"
import { MainLayout } from "@/components/layout/main-layout"
import { ProductTable } from "@/components/products/product-table"

export default function ProductsPage() {
  return (
    <ProtectedRoute>
      <MainLayout>
        <div className="p-6">
          <ProductTable />
        </div>
      </MainLayout>
    </ProtectedRoute>
  )
}
