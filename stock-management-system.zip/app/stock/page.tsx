import { ProtectedRoute } from "@/components/auth/protected-route"
import { MainLayout } from "@/components/layout/main-layout"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { StockOverview } from "@/components/stock/stock-overview"
import { StockMovements } from "@/components/stock/stock-movements"

export default function StockPage() {
  return (
    <ProtectedRoute>
      <MainLayout>
        <div className="p-6">
          <div className="mb-6">
            <h1 className="text-3xl font-bold text-primary">Stock Control</h1>
            <p className="text-muted-foreground">Monitor stock levels and manage inventory movements</p>
          </div>

          <Tabs defaultValue="overview" className="space-y-6">
            <TabsList>
              <TabsTrigger value="overview">Stock Overview</TabsTrigger>
              <TabsTrigger value="movements">Movement History</TabsTrigger>
            </TabsList>

            <TabsContent value="overview">
              <StockOverview />
            </TabsContent>

            <TabsContent value="movements">
              <StockMovements />
            </TabsContent>
          </Tabs>
        </div>
      </MainLayout>
    </ProtectedRoute>
  )
}
